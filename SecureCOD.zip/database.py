import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cod_orders.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(seed=True):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Products Catalog
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            original_price REAL NOT NULL,
            image TEXT NOT NULL,
            badge TEXT,
            rating REAL DEFAULT 4.8,
            reviews INTEGER DEFAULT 120
        )
    ''')

    # Registered Address & Owner Registry (Maps addresses to genuine owners)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS address_registry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            address_keyword TEXT NOT NULL,
            pincode TEXT NOT NULL,
            owner_name TEXT NOT NULL,
            owner_phone TEXT NOT NULL
        )
    ''')

    # Orders Table with Owner Confirmation Lifecycle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            buyer_name TEXT NOT NULL,
            buyer_phone TEXT NOT NULL,
            address TEXT NOT NULL,
            landmark TEXT NOT NULL,
            city TEXT NOT NULL,
            pincode TEXT NOT NULL,
            total_amount REAL NOT NULL,
            
            -- Owner Verification Lifecycle
            owner_name TEXT NOT NULL,
            owner_phone TEXT NOT NULL,
            owner_status TEXT NOT NULL, -- 'PENDING' (On Hold), 'APPROVED', 'REJECTED'
            owner_action_time TEXT,
            owner_rejection_reason TEXT,
            
            -- Shipment Status
            shipment_status TEXT NOT NULL, -- 'ON_HOLD', 'APPROVED_FOR_DISPATCH', 'DISPATCHED', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED_UNAUTHORIZED'
            courier TEXT,
            payment_collected_type TEXT,
            notes TEXT
        )
    ''')

    # Order Items
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT NOT NULL,
            product_id TEXT NOT NULL,
            product_name TEXT NOT NULL,
            price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders (id)
        )
    ''')

    conn.commit()

    if seed:
        seed_data(cursor, conn)

    conn.close()

def seed_data(cursor, conn):
    # Seed Products
    cursor.execute('SELECT COUNT(*) FROM products')
    if cursor.fetchone()[0] == 0:
        products = [
            ('p1', 'Wireless Noise Cancelling Earbuds', 1899.0, 3499.0, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500&auto=format&fit=crop&q=60', 'Best Seller', 4.8, 249),
            ('p2', 'Smart Fitness Tracker Watch with SpO2', 2499.0, 4999.0, 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500&auto=format&fit=crop&q=60', 'Trending', 4.7, 184),
            ('p3', 'Minimalist Leather Bi-Fold Wallet', 799.0, 1499.0, 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=500&auto=format&fit=crop&q=60', 'Popular', 4.9, 312),
            ('p4', '20,000mAh Fast Charging Power Bank', 1299.0, 2299.0, 'https://images.unsplash.com/photo-1609592424361-b44c66914561?w=500&auto=format&fit=crop&q=60', 'High Demand', 4.6, 95)
        ]
        cursor.executemany('''
            INSERT INTO products (id, name, price, original_price, image, badge, rating, reviews)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', products)

    # Seed Address Registry (Known residents/owners)
    cursor.execute('SELECT COUNT(*) FROM address_registry')
    if cursor.fetchone()[0] == 0:
        registry = [
            ('Flat 402, Green Valley Apartments', '560001', 'Rahul Sharma (Owner)', '+91 98765 43210'),
            ('Villa 12, Palm Meadows, Whitefield', '560066', 'Pooja Verma (House Owner)', '+91 98234 11223'),
            ('B-204, Sky Greens, Sector 45', '122003', 'Vikram Joshi (Apartment Owner)', '+91 97112 33445'),
            ('77 Lake Gardens, Southern Avenue', '700045', 'Amitabh Roy (Property Owner)', '+91 91234 56789')
        ]
        cursor.executemany('''
            INSERT INTO address_registry (address_keyword, pincode, owner_name, owner_phone)
            VALUES (?, ?, ?, ?)
        ''', registry)

    # Seed Sample Orders Demonstrating All 3 States:
    # 1. PENDING (On Hold awaiting address owner confirmation)
    # 2. APPROVED (Owner approved -> Ready for dispatch)
    # 3. REJECTED (Owner rejected unauthorized order -> Cancelled before dispatch, saving courier fees)
    cursor.execute('SELECT COUNT(*) FROM orders')
    if cursor.fetchone()[0] == 0:
        orders = [
            # Case 1: Currently ON HOLD awaiting address owner confirmation
            (
                'COD-101', '2026-10-13 16:30', 'Rohan (Unverified Buyer)', '+91 99123 00011',
                'Villa 12, Palm Meadows, Whitefield', 'Opposite Forum Mall', 'Bengaluru', '560066', 2499.0,
                'Pooja Verma (House Owner)', '+91 98234 11223', 'PENDING', None, None,
                'ON_HOLD', 'Hold - Dispatch Frozen', None,
                'Order placed on hold. Confirmation request sent to address owner Pooja Verma.'
            ),
            # Case 2: Owner Approved -> Cleared for dispatch & shipped
            (
                'COD-102', '2026-10-13 14:15', 'Rahul Sharma', '+91 98765 43210',
                'Flat 402, Green Valley Apartments, MG Road', 'Near City Metro Pillar 120', 'Bengaluru', '560001', 1899.0,
                'Rahul Sharma (Owner)', '+91 98765 43210', 'APPROVED', '2026-10-13 14:18', None,
                'DISPATCHED', 'Shadowfax Express (Rider: Arvind K.)', None,
                'Address owner approved delivery. Dispatched from fulfillment center.'
            ),
            # Case 3: Unauthorized Address Order REJECTED by real owner! (Fake COD stopped before dispatch!)
            (
                'COD-103', '2026-10-13 11:40', 'Anonymous Prankster', '+91 98999 55555',
                'B-204, Sky Greens, Sector 45', 'Near Cyber Hub', 'Gurugram', '122003', 1299.0,
                'Vikram Joshi (Apartment Owner)', '+91 97112 33445', 'REJECTED', '2026-10-13 11:45',
                'Unauthorized order. I did not order this item and will not accept COD payment at my address.',
                'CANCELLED_UNAUTHORIZED', 'None (Saved ₹220 Courier Fee)', None,
                'BLOCKED BEFORE DISPATCH: Address owner Vikram Joshi rejected the order.'
            )
        ]
        cursor.executemany('''
            INSERT INTO orders (id, created_at, buyer_name, buyer_phone, address, landmark, city, pincode, total_amount, owner_name, owner_phone, owner_status, owner_action_time, owner_rejection_reason, shipment_status, courier, payment_collected_type, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', orders)

        items = [
            ('COD-101', 'p2', 'Smart Fitness Tracker Watch with SpO2', 2499.0, 1),
            ('COD-102', 'p1', 'Wireless Noise Cancelling Earbuds', 1899.0, 1),
            ('COD-103', 'p4', '20,000mAh Fast Charging Power Bank', 1299.0, 1)
        ]
        cursor.executemany('''
            INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
            VALUES (?, ?, ?, ?, ?)
        ''', items)

    conn.commit()

def reset_database():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DROP TABLE IF EXISTS order_items')
    cursor.execute('DROP TABLE IF EXISTS orders')
    cursor.execute('DROP TABLE IF EXISTS address_registry')
    cursor.execute('DROP TABLE IF EXISTS products')
    conn.commit()
    conn.close()
    init_db(seed=True)

if __name__ == '__main__':
    reset_database()
    print("Database initialized successfully at:", DB_PATH)
