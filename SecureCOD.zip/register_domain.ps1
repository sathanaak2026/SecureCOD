$hosts = "$env:WINDIR\System32\drivers\etc\hosts"
if (-not (Select-String -Path $hosts -Pattern "securecod" -Quiet)) {
    Add-Content -Path $hosts -Value "`n127.0.0.1 securecod`n127.0.0.1 securecod.local"
    Write-Host "Success: Registered 'securecod' as IP 127.0.0.1" -ForegroundColor Green
} else {
    Write-Host "Already registered: 'securecod' maps to 127.0.0.1" -ForegroundColor Cyan
}
Start-Sleep -Seconds 2
