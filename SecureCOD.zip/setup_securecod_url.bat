@echo off
title Setup SecureCOD Custom URL
echo ========================================================
echo   Setting up custom URL: http://securecod:5000
echo ========================================================

net session >nul 2>&1
if %errorLevel% == 0 (
    echo [OK] Administrator access confirmed.
    findstr /i "securecod" %WINDIR%\System32\drivers\etc\hosts >nul
    if %errorLevel% == 0 (
        echo [INFO] "securecod" is already registered in your Windows hosts file!
    ) else (
        echo. >> %WINDIR%\System32\drivers\etc\hosts
        echo 127.0.0.1 securecod >> %WINDIR%\System32\drivers\etc\hosts
        echo 127.0.0.1 securecod.local >> %WINDIR%\System32\drivers\etc\hosts
        echo [SUCCESS] Added "securecod" mapping to Windows hosts file.
    )
    echo.
    echo ========================================================
    echo   You can now type this in any browser:
    echo   -> http://securecod:5000
    echo ========================================================
    echo.
    pause
) else (
    echo Requesting Administrator permissions to update Windows hosts file...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
)
