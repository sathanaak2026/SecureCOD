# SecureCOD — Verification System to Prevent Fake COD Orders Placed Using Unauthorized Addresses

A specialized web prototype built to solve the industry problem of **fake/prank Cash-on-Delivery (COD) orders placed at unsuspecting people's addresses**, which cause massive Return-to-Origin (RTO) courier costs and merchant losses.

---

## 🎯 The Problem Statement
> **Verification System to Prevent Fake COD Orders Placed Using Unauthorized Addresses**
>
> Malicious buyers or pranksters place COD orders specifying addresses of strangers or random victims. When the courier executive arrives, the occupant refuses delivery (*"I never ordered this!"*). The merchant loses ₹200–₹300 in round-trip shipping penalties, and logistics capacity is wasted.

---

## 💡 The Proposed Solution Implemented in this Prototype

1. **Verify COD Orders Before Dispatch**:
   - Every COD order enters a pre-dispatch verification gatekeeper before the warehouse packs or hands it to the courier.
2. **Confirmation Request to the Address Owner**:
   - The system triggers an instant confirmation alert directly to the registered householder or property owner of the delivery address.
3. **Owner Can Approve or Reject**:
   - **Approve**: If the owner authorizes it, the order is cleared for warehouse packing and courier dispatch.
   - **Reject**: If the owner denies ordering it, the order is **instantly cancelled BEFORE dispatch**, saving 100% of the courier shipping and RTO costs.
4. **Orders Without Confirmation are Placed On Hold**:
   - While awaiting confirmation, the order status is locked in `ON_HOLD`.
   - The merchant portal physically disables dispatch to eliminate risk.

---

## 🚀 How to Run the Prototype

1. Open Windows PowerShell:
```powershell
cd C:\Users\lenovo\.gemini\antigravity\scratch\cod-order-prototype
python app.py
```

2. Open your browser:
👉 **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

*(Alternatively, double-click `run.bat` to launch everything with one click)*

---

## 🧭 Interactive Demo Walkthrough

### Scenario A: Malicious Prankster Orders to Someone Else's House
1. In the **1. Place COD Order** tab, select a product.
2. Select the preset **"⚠️ Malicious / Unauthorized Prank Address"** (Buyer: *Anonymous Prankster*, Address: *Villa 12, Palm Meadows*, Real Owner: *Pooja Verma*).
3. Click **Place COD Order**.
4. The system immediately places the order **ON HOLD** and alerts the real owner Pooja Verma.
5. Switch to **2. Address Owner Phone** tab. Notice the incoming authorization alert.
6. Click **Reject Order (Unauthorized Address)**.
7. **Result**: The order is cancelled instantly before dispatch, and the system logs **₹220 saved in courier RTO fees**!

### Scenario B: Legitimate Order
1. Place an order for **"Flat 402, Green Valley"** (Owner: *Rahul Sharma*).
2. Go to **2. Address Owner Phone** tab and click **Approve Order**.
3. Go to **3. Merchant Dispatch Portal**. The dispatch button is now **unlocked**! Click **Dispatch Now** to ship the parcel.
