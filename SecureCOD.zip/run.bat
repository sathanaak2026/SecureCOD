@echo off
title SecureCOD Prototype Server
echo ========================================================
echo   Launching SecureCOD Prototype
echo   URL: http://securecod:5000
echo   (or: http://127.0.0.1:5000)
echo ========================================================
timeout /t 2 /nobreak >nul
start "" "http://securecod:5000"
python app.py
pause
