from flask import Flask, request, jsonify, render_template
import random
from datetime import datetime
import database

app = Flask(__name__, template_folder='templates', static_folder='static')
database.init_db()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/products', methods=['GET'])
def get_products():
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM products')
    rows = cursor.fetchall()
    conn.close()

    products = [{
        'id': r['id'],
        'name': r['name'],
        'price': r['price'],
        'originalPrice': r['original_price'],
        'image': r['image'],
        'badge': r['badge'],
        'rating': r['rating'],
        'reviews': r['reviews']
    } for r in rows]
    return jsonify({'products': products})

@app.route('/api/address-registry', methods=['GET'])
def get_address_registry():
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM address_registry')
    rows = cursor.fetchall()
    conn.close()

    registry = [{
        'id': r['id'],
        'addressKeyword': r['address_keyword'],
        'pincode': r['pincode'],
        'ownerName': r['owner_name'],
        'ownerPhone': r['owner_phone']
    } for r in rows]
    return jsonify({'registry': registry})

@app.route('/api/orders', methods=['GET'])
def get_orders():
    search = request.args.get('search', '').strip().lower()
    status_filter = request.args.get('status', 'ALL').strip().upper()

    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders ORDER BY created_at DESC')
    rows = cursor.fetchall()

    orders = []
    for r in rows:
        order_id = r['id']
        cursor.execute('SELECT * FROM order_items WHERE order_id = ?', (order_id,))
        items = [{
            'productId': item['product_id'],
            'name': item['product_name'],
            'price': item['price'],
            'quantity': item['quantity']
        } for item in cursor.fetchall()]

        order_data = {
            'id': r['id'],
            'createdAt': r['created_at'],
            'buyer': {
                'name': r['buyer_name'],
                'phone': r['buyer_phone']
            },
            'address': {
                'text': r['address'],
                'landmark': r['landmark'],
                'city': r['city'],
                'pincode': r['pincode']
            },
            'items': items,
            'totalAmount': r['total_amount'],
            'owner': {
                'name': r['owner_name'],
                'phone': r['owner_phone'],
                'status': r['owner_status'], # 'PENDING', 'APPROVED', 'REJECTED'
                'actionTime': r['owner_action_time'],
                'rejectionReason': r['owner_rejection_reason']
            },
            'shipmentStatus': r['shipment_status'], # 'ON_HOLD', 'APPROVED_FOR_DISPATCH', 'DISPATCHED', etc.
            'courier': r['courier'],
            'paymentCollectedType': r['payment_collected_type'],
            'notes': r['notes']
        }

        matches_query = (
            not search or
            search in order_id.lower() or
            search in r['buyer_name'].lower() or
            search in r['owner_name'].lower() or
            search in r['address'].lower() or
            search in r['pincode']
        )
        matches_status = (
            status_filter == 'ALL' or
            r['shipment_status'] == status_filter or
            r['owner_status'] == status_filter
        )

        if matches_query and matches_status:
            orders.append(order_data)

    conn.close()
    return jsonify({'orders': orders})

@app.route('/api/orders/<order_id>', methods=['GET'])
def get_order_detail(order_id):
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
    r = cursor.fetchone()
    if not r:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    cursor.execute('SELECT * FROM order_items WHERE order_id = ?', (order_id,))
    items = [{
        'productId': item['product_id'],
        'name': item['product_name'],
        'price': item['price'],
        'quantity': item['quantity']
    } for item in cursor.fetchall()]
    conn.close()

    return jsonify({
        'order': {
            'id': r['id'],
            'createdAt': r['created_at'],
            'buyer': {
                'name': r['buyer_name'],
                'phone': r['buyer_phone']
            },
            'address': {
                'text': r['address'],
                'landmark': r['landmark'],
                'city': r['city'],
                'pincode': r['pincode']
            },
            'items': items,
            'totalAmount': r['total_amount'],
            'owner': {
                'name': r['owner_name'],
                'phone': r['owner_phone'],
                'status': r['owner_status'],
                'actionTime': r['owner_action_time'],
                'rejectionReason': r['owner_rejection_reason']
            },
            'shipmentStatus': r['shipment_status'],
            'courier': r['courier'],
            'paymentCollectedType': r['payment_collected_type'],
            'notes': r['notes']
        }
    })

@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.get_json() or {}
    buyer = data.get('buyer', {})
    address = data.get('address', {})
    owner = data.get('owner', {})
    items = data.get('items', [])
    total_amount = float(data.get('totalAmount', 0))

    if not buyer.get('name') or not buyer.get('phone') or not items:
        return jsonify({'error': 'Missing buyer details or cart items'}), 400

    order_id = f"COD-{random.randint(100, 999)}"
    created_at = datetime.now().strftime('%Y-%m-%d %H:%M')

    # Look up registered owner if not explicitly provided
    owner_name = owner.get('name')
    owner_phone = owner.get('phone')

    conn = database.get_db_connection()
    cursor = conn.cursor()

    if not owner_name or not owner_phone:
        # Auto-match from registry by address keyword or pincode
        cursor.execute('SELECT owner_name, owner_phone FROM address_registry WHERE pincode = ? LIMIT 1', (address.get('pincode', ''),))
        match = cursor.fetchone()
        if match:
            owner_name = match['owner_name']
            owner_phone = match['owner_phone']
        else:
            owner_name = f"Property Owner ({address.get('city', 'Resident')})"
            owner_phone = "+91 98765 00000"

    # Core Rule: Orders without confirmation are placed on hold!
    cursor.execute('''
        INSERT INTO orders (
            id, created_at, buyer_name, buyer_phone, address, landmark, city, pincode,
            total_amount, owner_name, owner_phone, owner_status, owner_action_time,
            owner_rejection_reason, shipment_status, courier, payment_collected_type, notes
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        order_id, created_at, buyer.get('name'), buyer.get('phone'),
        address.get('text', ''), address.get('landmark', ''), address.get('city', ''), address.get('pincode', ''),
        total_amount, owner_name, owner_phone,
        'PENDING', # On Hold waiting for owner
        None, None,
        'ON_HOLD', # Frozen before dispatch
        'Hold - Dispatch Frozen',
        None,
        f'Order placed on hold. Confirmation request sent to address owner {owner_name} ({owner_phone}).'
    ))

    for item in items:
        cursor.execute('''
            INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
            VALUES (?, ?, ?, ?, ?)
        ''', (order_id, item.get('id', 'p1'), item.get('name', 'Product'), float(item.get('price', 0)), int(item.get('quantity', 1))))

    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'orderId': order_id,
        'status': 'ON_HOLD',
        'ownerName': owner_name,
        'ownerPhone': owner_phone,
        'message': f'Order placed on hold. Confirmation request sent to address owner {owner_name}.'
    }), 201

# The address owner approves or rejects the COD order
@app.route('/api/orders/<order_id>/owner-action', methods=['POST'])
def handle_owner_action(order_id):
    data = request.get_json() or {}
    action = data.get('action', '').upper() # 'APPROVE' or 'REJECT'
    reason = data.get('reason', '').strip()
    action_time = datetime.now().strftime('%Y-%m-%d %H:%M')

    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    if action == 'APPROVE':
        cursor.execute('''
            UPDATE orders
            SET owner_status = 'APPROVED',
                owner_action_time = ?,
                shipment_status = 'APPROVED_FOR_DISPATCH',
                courier = 'Shadowfax Express (Ready for pickup)',
                notes = 'Address owner confirmed this delivery. Cleared for warehouse packing and dispatch.'
            WHERE id = ?
        ''', (action_time, order_id))
        conn.commit()
        conn.close()
        return jsonify({
            'success': True,
            'orderId': order_id,
            'ownerStatus': 'APPROVED',
            'shipmentStatus': 'APPROVED_FOR_DISPATCH',
            'message': 'Order approved by address owner! Cleared for dispatch.'
        })

    elif action == 'REJECT':
        if not reason:
            reason = 'Unauthorized order. I did not order this item to my address.'
        cursor.execute('''
            UPDATE orders
            SET owner_status = 'REJECTED',
                owner_action_time = ?,
                owner_rejection_reason = ?,
                shipment_status = 'CANCELLED_UNAUTHORIZED',
                courier = 'None (Saved ₹220 Courier Logistics Fee)',
                notes = ?
            WHERE id = ?
        ''', (
            action_time, reason,
            f'BLOCKED BEFORE DISPATCH: Address owner rejected unauthorized order: "{reason}". Zero courier costs incurred.',
            order_id
        ))
        conn.commit()
        conn.close()
        return jsonify({
            'success': True,
            'orderId': order_id,
            'ownerStatus': 'REJECTED',
            'shipmentStatus': 'CANCELLED_UNAUTHORIZED',
            'savedCourierFee': 220,
            'message': 'Order rejected by address owner. Cancelled before dispatch, saving courier RTO fees.'
        })

    else:
        conn.close()
        return jsonify({'error': 'Invalid action. Must be APPROVE or REJECT'}), 400

# Merchant attempts to dispatch
@app.route('/api/orders/<order_id>/dispatch', methods=['POST'])
def dispatch_order(order_id):
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    # Enforce Rule: Orders without owner confirmation CANNOT be dispatched!
    if row['owner_status'] != 'APPROVED':
        conn.close()
        return jsonify({
            'error': 'DISPATCH BLOCKED: This COD order is still ON HOLD awaiting confirmation from the address owner.',
            'currentOwnerStatus': row['owner_status'],
            'shipmentStatus': row['shipment_status']
        }), 400

    cursor.execute('''
        UPDATE orders
        SET shipment_status = 'DISPATCHED',
            courier = 'Shadowfax Express (In Transit to Destination Hub)',
            notes = 'Dispatched from fulfillment center following address owner authorization.'
        WHERE id = ?
    ''', (order_id,))
    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'orderId': order_id,
        'shipmentStatus': 'DISPATCHED',
        'message': 'Order dispatched successfully.'
    })

# Courier marks out for delivery and collects cash
@app.route('/api/orders/<order_id>/deliver', methods=['POST'])
def deliver_order(order_id):
    data = request.get_json() or {}
    payment_type = data.get('paymentType', 'Cash in Hand')

    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
    row = cursor.fetchone()

    if not row:
        conn.close()
        return jsonify({'error': 'Order not found'}), 404

    cursor.execute('''
        UPDATE orders
        SET shipment_status = 'DELIVERED',
            payment_collected_type = ?,
            notes = ?
        WHERE id = ?
    ''', (payment_type, f'Delivered & ₹{row["total_amount"]:,.0f} collected via {payment_type}. Handover verified.', order_id))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'orderId': order_id, 'shipmentStatus': 'DELIVERED'})

@app.route('/api/analytics', methods=['GET'])
def get_analytics():
    conn = database.get_db_connection()
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM orders')
    total_orders = cursor.fetchone()[0]

    # Orders on hold
    cursor.execute("SELECT COUNT(*) FROM orders WHERE owner_status = 'PENDING'")
    on_hold_count = cursor.fetchone()[0]

    # Owner approved
    cursor.execute("SELECT COUNT(*) FROM orders WHERE owner_status = 'APPROVED'")
    approved_count = cursor.fetchone()[0]

    # Unauthorized / Fake orders blocked by owner
    cursor.execute("SELECT COUNT(*) FROM orders WHERE owner_status = 'REJECTED'")
    rejected_count = cursor.fetchone()[0]

    # Courier fees saved (average ₹220 per fake order prevented from shipping)
    fees_saved = rejected_count * 220

    # Total Cash Collected on delivered orders
    cursor.execute("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE shipment_status = 'DELIVERED'")
    cash_collected = cursor.fetchone()[0]

    conn.close()
    return jsonify({
        'totalOrders': total_orders,
        'onHoldCount': on_hold_count,
        'approvedCount': approved_count,
        'rejectedCount': rejected_count,
        'feesSaved': fees_saved,
        'cashCollected': cash_collected
    })

@app.route('/api/reset', methods=['POST'])
def reset_demo():
    database.reset_database()
    return jsonify({'success': True, 'message': 'Demo database restored to default seed state'})

if __name__ == '__main__':
    print("=====================================================")
    print("  SecureCOD - Address Owner Verification System")
    print("  -> Local:   http://127.0.0.1:5000")
    print("  -> Network: http://0.0.0.0:5000")
    print("=====================================================")
    app.run(host='0.0.0.0', port=5000, debug=True)
