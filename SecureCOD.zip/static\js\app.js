// COD Pre-Dispatch Address Owner Verification System
// Frontend Application Controller

let products = [];
let orders = [];
let addressRegistry = [];
let currentTrackingOrder = null;
let activeOwnerActionOrderId = null;

// Initialize App
async function initApp() {
  await loadProducts();
  await loadAddressRegistry();
  await loadOrders();
  await loadAnalytics();

  renderProductGrid();
  populateAddressPresets();
  renderOrdersTable();
  renderOwnerVerificationPortal();
  renderTrackingOrder();
  lucide.createIcons();
}

// Data Fetching
async function loadProducts() {
  try {
    const res = await fetch('/api/products');
    const data = await res.json();
    products = data.products || [];
  } catch(e) {
    console.error(e);
  }
}

async function loadAddressRegistry() {
  try {
    const res = await fetch('/api/address-registry');
    const data = await res.json();
    addressRegistry = data.registry || [];
  } catch(e) {
    console.error(e);
  }
}

async function loadOrders(search = '', status = 'ALL') {
  try {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (status !== 'ALL') params.append('status', status);

    const res = await fetch(`/api/orders?${params.toString()}`);
    const data = await res.json();
    orders = data.orders || [];
  } catch(e) {
    console.error(e);
  }
}

async function loadAnalytics() {
  try {
    const res = await fetch('/api/analytics');
    const data = await res.json();
    
    document.getElementById('kpi-total').innerText = data.totalOrders;
    document.getElementById('kpi-on-hold').innerText = data.onHoldCount;
    document.getElementById('kpi-approved').innerText = data.approvedCount;
    document.getElementById('kpi-rejected').innerText = data.rejectedCount;
    document.getElementById('kpi-saved').innerText = `₹${data.feesSaved.toLocaleString()}`;
    
    // Header pill
    const holdBadge = document.getElementById('nav-hold-badge');
    if (data.onHoldCount > 0) {
      holdBadge.classList.remove('hidden');
      holdBadge.innerText = `${data.onHoldCount} On Hold`;
    } else {
      holdBadge.classList.add('hidden');
    }
  } catch(e) {
    console.error(e);
  }
}

// Tab Switching
function switchView(viewName) {
  document.querySelectorAll('.view-panel').forEach(el => el.classList.add('hidden'));
  document.querySelectorAll('.nav-tab').forEach(el => {
    el.classList.remove('bg-white', 'text-slate-900', 'shadow-sm', 'font-bold');
    el.classList.add('text-slate-600');
  });

  const targetView = document.getElementById(`view-${viewName}`);
  const targetBtn = document.getElementById(`nav-btn-${viewName}`);

  if (targetView) targetView.classList.remove('hidden');
  if (targetBtn) {
    targetBtn.classList.remove('text-slate-600');
    targetBtn.classList.add('bg-white', 'text-slate-900', 'shadow-sm', 'font-bold');
  }

  if (viewName === 'owner') renderOwnerVerificationPortal();
  if (viewName === 'admin') renderOrdersTable();
  if (viewName === 'track') renderTrackingOrder();

  lucide.createIcons();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Storefront Product Grid
function renderProductGrid() {
  const container = document.getElementById('product-grid');
  container.innerHTML = products.map(prod => `
    <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between group">
      <div>
        <div class="relative h-44 w-full bg-slate-100 overflow-hidden">
          <img src="${prod.image}" alt="${prod.name}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
          <span class="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
            ${prod.badge}
          </span>
          <span class="absolute bottom-3 right-3 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">
            COD Available
          </span>
        </div>
        <div class="p-4 space-y-2">
          <div class="flex items-center gap-1 text-amber-500 text-xs font-semibold">
            <i data-lucide="star" class="w-3.5 h-3.5 fill-amber-400 text-amber-400"></i>
            <span>${prod.rating}</span>
            <span class="text-slate-400 font-normal">(${prod.reviews} reviews)</span>
          </div>
          <h3 class="font-bold text-slate-900 text-sm line-clamp-2 leading-snug">${prod.name}</h3>
          <div class="flex items-baseline gap-2 pt-1">
            <span class="text-lg font-extrabold text-slate-900">₹${prod.price.toLocaleString()}</span>
            <span class="text-xs text-slate-400 line-through">₹${prod.originalPrice.toLocaleString()}</span>
          </div>
        </div>
      </div>
      <div class="p-4 pt-0">
        <button onclick="openOrderModal('${prod.id}')" class="w-full py-2.5 px-3 bg-slate-900 hover:bg-emerald-600 text-white text-xs font-semibold rounded-xl transition flex items-center justify-center gap-2 shadow-sm">
          <i data-lucide="shopping-bag" class="w-4 h-4"></i>
          <span>Order via COD (Test Verification)</span>
        </button>
      </div>
    </div>
  `).join('');
  lucide.createIcons();
}

// Order Modal & Presets
let selectedProductForOrder = null;

function populateAddressPresets() {
  const select = document.getElementById('address-preset-select');
  select.innerHTML = `
    <option value="">-- Choose an Address Preset (or type custom below) --</option>
    ${addressRegistry.map(reg => `
      <option value="${reg.id}">
        📍 ${reg.addressKeyword} (Owner: ${reg.ownerName} - ${reg.ownerPhone})
      </option>
    `).join('')}
    <option value="custom_unauthorized">⚠️ Malicious / Unauthorized Prank Address (Random Stranger's Home)</option>
  `;
}

function handlePresetSelect(presetId) {
  if (!presetId) return;

  if (presetId === 'custom_unauthorized') {
    document.getElementById('input-address').value = 'Villa 12, Palm Meadows, Whitefield';
    document.getElementById('input-landmark').value = 'Opposite Forum Mall';
    document.getElementById('input-city').value = 'Bengaluru';
    document.getElementById('input-pincode').value = '560066';
    document.getElementById('input-owner-name').value = 'Pooja Verma (House Owner)';
    document.getElementById('input-owner-phone').value = '+91 98234 11223';
    document.getElementById('input-buyer-name').value = 'Anonymous Prankster';
    document.getElementById('input-buyer-phone').value = '+91 99999 11111';
    return;
  }

  const reg = addressRegistry.find(r => r.id === parseInt(presetId));
  if (!reg) return;

  document.getElementById('input-address').value = reg.addressKeyword;
  document.getElementById('input-landmark').value = 'Near Metro / Main Gate';
  document.getElementById('input-city').value = 'Bengaluru';
  document.getElementById('input-pincode').value = reg.pincode;
  document.getElementById('input-owner-name').value = reg.ownerName;
  document.getElementById('input-owner-phone').value = reg.ownerPhone;
}

function openOrderModal(productId) {
  selectedProductForOrder = products.find(p => p.id === productId) || products[0];
  document.getElementById('modal-prod-name').innerText = selectedProductForOrder.name;
  document.getElementById('modal-prod-price').innerText = `₹${selectedProductForOrder.price.toLocaleString()}`;
  document.getElementById('modal-prod-img').src = selectedProductForOrder.image;
  document.getElementById('order-modal').classList.remove('hidden');
}

function closeOrderModal() {
  document.getElementById('order-modal').classList.add('hidden');
}

// Submit COD Order
async function submitCodOrder(e) {
  e.preventDefault();
  if (!selectedProductForOrder) return;

  const payload = {
    buyer: {
      name: document.getElementById('input-buyer-name').value,
      phone: document.getElementById('input-buyer-phone').value
    },
    address: {
      text: document.getElementById('input-address').value,
      landmark: document.getElementById('input-landmark').value,
      city: document.getElementById('input-city').value,
      pincode: document.getElementById('input-pincode').value
    },
    owner: {
      name: document.getElementById('input-owner-name').value,
      phone: document.getElementById('input-owner-phone').value
    },
    items: [{
      id: selectedProductForOrder.id,
      name: selectedProductForOrder.name,
      price: selectedProductForOrder.price,
      quantity: 1
    }],
    totalAmount: selectedProductForOrder.price
  };

  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();

    if (result.success) {
      closeOrderModal();
      await loadOrders();
      await loadAnalytics();

      showToast(
        "Order Placed on HOLD!",
        `Confirmation request dispatched to address owner: ${result.ownerName} (${result.ownerPhone}). Dispatch is frozen until verified.`
      );

      // Select newly placed order for viewing
      currentTrackingOrder = orders.find(o => o.id === result.orderId);
      
      // Auto-open Address Owner portal so user can test approval/rejection immediately
      setTimeout(() => {
        switchView('owner');
      }, 700);
    }
  } catch(err) {
    console.error(err);
    alert("Error placing order");
  }
}

// ========================================================
// ADDRESS OWNER VERIFICATION PORTAL (The Core Feature)
// ========================================================
function renderOwnerVerificationPortal() {
  const container = document.getElementById('owner-requests-container');
  const pendingOrders = orders.filter(o => o.owner.status === 'PENDING');

  if (pendingOrders.length === 0) {
    container.innerHTML = `
      <div class="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
        <div class="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto">
          <i data-lucide="check-circle" class="w-6 h-6"></i>
        </div>
        <h3 class="font-bold text-slate-900 text-base">No Pending Address Confirmation Requests</h3>
        <p class="text-xs text-slate-500 max-w-md mx-auto">
          All orders have either been authorized or blocked. Place a new COD order from the Storefront tab to simulate a fresh address confirmation alert!
        </p>
        <button onclick="switchView('store')" class="text-xs bg-slate-900 text-white font-semibold px-4 py-2 rounded-xl hover:bg-slate-800 transition">
          + Place Test COD Order
        </button>
      </div>
    `;
    lucide.createIcons();
    return;
  }

  container.innerHTML = pendingOrders.map(order => `
    <div class="bg-white rounded-2xl border-2 border-amber-300 shadow-lg p-6 space-y-5 relative overflow-hidden">
      <!-- Amber alert ribbon -->
      <div class="bg-amber-500 text-white text-[11px] font-bold px-4 py-1 absolute top-0 right-0 rounded-bl-xl uppercase tracking-wider flex items-center gap-1.5">
        <i data-lucide="clock" class="w-3.5 h-3.5"></i> Order Held — Awaiting Your Consent
      </div>

      <!-- Header -->
      <div class="space-y-1 pt-2">
        <div class="flex items-center gap-2">
          <span class="font-mono font-bold text-slate-900 text-lg">#${order.id}</span>
          <span class="text-xs bg-amber-100 text-amber-900 font-bold px-2.5 py-0.5 rounded-full">COD Payment: ₹${order.totalAmount.toLocaleString()}</span>
        </div>
        <p class="text-xs text-slate-500">Alert sent to address owner: <strong class="text-slate-800">${order.owner.name}</strong> (${order.owner.phone})</p>
      </div>

      <!-- Verification Question Banner -->
      <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-4 space-y-2">
        <h4 class="font-bold text-slate-900 text-sm flex items-center gap-2">
          <i data-lucide="help-circle" class="w-5 h-5 text-amber-600"></i>
          Did you authorize a Cash-on-Delivery order to your address?
        </h4>
        <p class="text-xs text-slate-600 leading-relaxed">
          Someone entered your address for a COD parcel. If you did NOT order this, reject it below to immediately cancel the parcel and prevent courier harassment at your doorstep.
        </p>
      </div>

      <!-- Order Summary Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div class="space-y-1.5">
          <div class="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">Delivery Address</div>
          <div class="font-bold text-slate-900">${order.address.text}</div>
          <div class="text-slate-600">${order.address.city} - ${order.address.pincode} (${order.address.landmark})</div>
        </div>
        <div class="space-y-1.5">
          <div class="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">Order Details & Buyer</div>
          <div class="font-bold text-slate-900">${order.items.map(i => i.name).join(', ')}</div>
          <div class="text-slate-600">Ordered by: <strong>${order.buyer.name}</strong> (${order.buyer.phone})</div>
          <div class="text-emerald-700 font-bold">Payable at Doorstep: ₹${order.totalAmount.toLocaleString()}</div>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="flex flex-col sm:flex-row items-stretch gap-3 pt-2">
        <button onclick="respondOwnerAction('${order.id}', 'APPROVE')" class="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition flex items-center justify-center gap-2">
          <i data-lucide="check-circle" class="w-4 h-4"></i>
          <span>Approve Order (I Authorize This Delivery)</span>
        </button>

        <button onclick="openRejectReasonModal('${order.id}')" class="flex-1 py-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2">
          <i data-lucide="x-circle" class="w-4 h-4"></i>
          <span>Reject Order (Unauthorized Address / Fake Order)</span>
        </button>
      </div>
    </div>
  `).join('');
  lucide.createIcons();
}

// Address Owner Action: Approve or Reject
async function respondOwnerAction(orderId, action, reason = '') {
  try {
    const res = await fetch(`/api/orders/${orderId}/owner-action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, reason })
    });
    const result = await res.json();

    if (result.success) {
      await loadOrders();
      await loadAnalytics();
      renderOwnerVerificationPortal();
      renderOrdersTable();

      if (action === 'APPROVE') {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
        showToast("Address Owner Approved!", `Order #${orderId} authorized by owner. Released from hold and cleared for warehouse dispatch.`);
      } else {
        showToast("Fake Order Blocked!", `Order #${orderId} rejected by real address owner. Cancelled before dispatch, saving ₹220 courier fee.`);
      }
    }
  } catch(err) {
    console.error(err);
  }
}

function openRejectReasonModal(orderId) {
  activeOwnerActionOrderId = orderId;
  document.getElementById('reject-modal').classList.remove('hidden');
}
function closeRejectReasonModal() {
  document.getElementById('reject-modal').classList.add('hidden');
}

function confirmRejectSubmit() {
  const reason = document.getElementById('reject-reason-select').value;
  respondOwnerAction(activeOwnerActionOrderId, 'REJECT', reason);
  closeRejectReasonModal();
}

// ========================================================
// MERCHANT PRE-DISPATCH CONTROL CENTER (Admin View)
// ========================================================
function renderOrdersTable() {
  const tbody = document.getElementById('admin-orders-tbody');
  const countEl = document.getElementById('admin-orders-count');
  countEl.innerText = `${orders.length} Total Orders`;

  if (orders.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400">No orders found.</td></tr>`;
    return;
  }

  tbody.innerHTML = orders.map(order => {
    const isHold = order.owner.status === 'PENDING';
    const isApproved = order.owner.status === 'APPROVED';
    const isRejected = order.owner.status === 'REJECTED';

    return `
      <tr class="hover:bg-slate-50 transition">
        <td class="py-4 px-4">
          <span class="font-mono font-bold text-slate-900">${order.id}</span>
          <span class="text-slate-400 block text-[11px]">${order.createdAt}</span>
        </td>

        <td class="py-4 px-4">
          <div class="font-semibold text-slate-800">${order.buyer.name}</div>
          <div class="text-slate-500 text-[11px]">${order.buyer.phone}</div>
          <div class="text-slate-600 text-[11px] mt-1 max-w-xs truncate font-medium">📍 ${order.address.text}</div>
        </td>

        <td class="py-4 px-4">
          <div class="font-bold text-slate-900 text-sm">₹${order.totalAmount.toLocaleString()}</div>
          <div class="text-[10px] text-emerald-600 font-semibold">Cash On Delivery</div>
        </td>

        <!-- Owner Confirmation Status -->
        <td class="py-4 px-4">
          ${isHold ? `
            <span class="inline-flex items-center gap-1 text-amber-800 bg-amber-100 px-2.5 py-1 rounded-full text-[11px] font-bold animate-pulse">
              <i data-lucide="clock" class="w-3.5 h-3.5"></i> ON HOLD (Awaiting Owner)
            </span>
            <div class="text-[10px] text-slate-500 mt-1">Owner: ${order.owner.name}</div>
          ` : isApproved ? `
            <span class="inline-flex items-center gap-1 text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-full text-[11px] font-bold">
              <i data-lucide="check-circle" class="w-3.5 h-3.5"></i> Owner Approved ✓
            </span>
            <div class="text-[10px] text-emerald-700 mt-1">${order.owner.actionTime || 'Verified'}</div>
          ` : `
            <span class="inline-flex items-center gap-1 text-rose-800 bg-rose-100 px-2.5 py-1 rounded-full text-[11px] font-bold">
              <i data-lucide="x-circle" class="w-3.5 h-3.5"></i> Owner Rejected ✗
            </span>
            <div class="text-[10px] text-rose-600 mt-1 truncate max-w-[160px]">${order.owner.rejectionReason || 'Unauthorized address'}</div>
          `}
        </td>

        <!-- Shipment / Pre-Dispatch Status -->
        <td class="py-4 px-4">
          <span class="badge ${getShipmentBadgeClass(order.shipmentStatus)}">
            ${formatShipmentStatus(order.shipmentStatus)}
          </span>
          <div class="text-[10px] text-slate-500 mt-1 max-w-[150px] truncate">${order.courier}</div>
        </td>

        <!-- Pre-Dispatch Actions -->
        <td class="py-4 px-4 text-right">
          <div class="flex items-center justify-end gap-2">
            ${isHold ? `
              <button onclick="attemptBlockedDispatch('${order.id}')" title="Dispatch is locked until owner confirms" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-not-allowed">
                <i data-lucide="lock" class="w-3 h-3"></i> Locked
              </button>
            ` : isApproved && order.shipmentStatus === 'APPROVED_FOR_DISPATCH' ? `
              <button onclick="dispatchOrder('${order.id}')" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow transition flex items-center gap-1">
                <i data-lucide="truck" class="w-3 h-3"></i> Dispatch Now
              </button>
            ` : order.shipmentStatus === 'DISPATCHED' ? `
              <button onclick="deliverOrder('${order.id}')" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1">
                <i data-lucide="banknote" class="w-3 h-3"></i> Collect Cash
              </button>
            ` : `
              <span class="text-xs text-slate-400">Completed</span>
            `}

            <button onclick="trackOrder('${order.id}')" class="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg">
              <i data-lucide="eye" class="w-4 h-4"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
  lucide.createIcons();
}

// Enforce rule: cannot dispatch on-hold orders
function attemptBlockedDispatch(orderId) {
  alert(`DISPATCH BLOCKED!\n\nOrder #${orderId} cannot be shipped because it is currently ON HOLD awaiting confirmation from the delivery address owner.\n\nThis prevents shipping costs and fake deliveries.`);
}

async function dispatchOrder(orderId) {
  try {
    const res = await fetch(`/api/orders/${orderId}/dispatch`, { method: 'POST' });
    const result = await res.json();
    if (result.success) {
      await loadOrders();
      await loadAnalytics();
      renderOrdersTable();
      showToast("Order Dispatched!", `Order #${orderId} marked as Dispatched with Shadowfax courier.`);
    } else {
      alert(result.error);
    }
  } catch(e) {
    console.error(e);
  }
}

async function deliverOrder(orderId) {
  try {
    const res = await fetch(`/api/orders/${orderId}/deliver`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentType: 'Cash in Hand' })
    });
    const result = await res.json();
    if (result.success) {
      await loadOrders();
      await loadAnalytics();
      renderOrdersTable();
      showToast("Delivered & Cash Collected", `Order #${orderId} delivered. Doorstep cash payment received.`);
    }
  } catch(e) {
    console.error(e);
  }
}

// Track Order
function trackOrder(orderId) {
  currentTrackingOrder = orders.find(o => o.id === orderId);
  switchView('track');
}

function renderTrackingOrder() {
  if (!currentTrackingOrder && orders.length > 0) {
    currentTrackingOrder = orders[0];
  }
  const container = document.getElementById('tracking-container');
  if (!currentTrackingOrder) {
    container.innerHTML = `<div class="p-8 text-center text-slate-400">No active orders to track.</div>`;
    return;
  }

  const order = currentTrackingOrder;
  const isHold = order.owner.status === 'PENDING';
  const isApproved = order.owner.status === 'APPROVED';
  const isRejected = order.owner.status === 'REJECTED';

  container.innerHTML = `
    <div class="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-sm">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-slate-400">TRACKING ORDER</span>
            <span class="font-mono font-bold text-slate-900 text-lg">#${order.id}</span>
            <span class="badge ${getShipmentBadgeClass(order.shipmentStatus)}">${formatShipmentStatus(order.shipmentStatus)}</span>
          </div>
          <p class="text-xs text-slate-500 mt-1">Placed on ${order.createdAt} • Cash On Delivery</p>
        </div>
        <div class="text-right">
          <span class="text-xs text-slate-400 block">COD AMOUNT</span>
          <span class="text-2xl font-extrabold text-emerald-700">₹${order.totalAmount.toLocaleString()}</span>
        </div>
      </div>

      <!-- Current State Explanatory Card -->
      ${isHold ? `
        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-amber-500 text-white flex items-center justify-center flex-shrink-0">
            <i data-lucide="shield-alert" class="w-5 h-5"></i>
          </div>
          <div>
            <h4 class="text-xs font-bold text-amber-950">Order Placed On Hold (Pre-Dispatch Verification)</h4>
            <p class="text-xs text-amber-800">
              A verification alert has been sent to address owner <strong>${order.owner.name}</strong> (${order.owner.phone}). Warehouse dispatch is paused until the owner gives consent.
            </p>
          </div>
        </div>
      ` : isApproved ? `
        <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center flex-shrink-0">
            <i data-lucide="shield-check" class="w-5 h-5"></i>
          </div>
          <div>
            <h4 class="text-xs font-bold text-emerald-950">Address Owner Consent Verified ✓</h4>
            <p class="text-xs text-emerald-800">
              Owner confirmed order legitimacy on ${order.owner.actionTime || 'today'}. Cleared for courier dispatch and delivery.
            </p>
          </div>
        </div>
      ` : `
        <div class="bg-rose-50 border border-rose-200 rounded-xl p-4 flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-rose-600 text-white flex items-center justify-center flex-shrink-0">
            <i data-lucide="alert-octagon" class="w-5 h-5"></i>
          </div>
          <div>
            <h4 class="text-xs font-bold text-rose-950">Cancelled: Unauthorized Address Usage Prevented</h4>
            <p class="text-xs text-rose-800">
              Address owner ${order.owner.name} rejected this delivery: "${order.owner.rejectionReason}". Zero shipping costs wasted.
            </p>
          </div>
        </div>
      `}

      <!-- 4-Stage Stepper -->
      <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
        <div class="p-3 rounded-xl bg-slate-50 flex items-center gap-3">
          <div class="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">✓</div>
          <div>
            <div class="text-xs font-bold text-slate-900">1. Order Placed</div>
            <div class="text-[10px] text-slate-500">COD recorded</div>
          </div>
        </div>

        <div class="p-3 rounded-xl ${isHold ? 'bg-amber-50 border border-amber-300' : isApproved ? 'bg-slate-50' : 'bg-rose-50'} flex items-center gap-3">
          <div class="w-7 h-7 rounded-full ${isHold ? 'bg-amber-500 text-white animate-pulse' : isApproved ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'} flex items-center justify-center text-xs font-bold">
            ${isHold ? '⏳' : isApproved ? '✓' : '✗'}
          </div>
          <div>
            <div class="text-xs font-bold text-slate-900">2. Owner Check</div>
            <div class="text-[10px] text-slate-500">${isHold ? 'Held on hold' : isApproved ? 'Approved' : 'Rejected'}</div>
          </div>
        </div>

        <div class="p-3 rounded-xl ${order.shipmentStatus === 'DISPATCHED' || order.shipmentStatus === 'DELIVERED' ? 'bg-slate-50' : 'opacity-40'} flex items-center gap-3">
          <div class="w-7 h-7 rounded-full ${order.shipmentStatus === 'DISPATCHED' || order.shipmentStatus === 'DELIVERED' ? 'bg-emerald-600 text-white' : 'bg-slate-300'} flex items-center justify-center text-xs font-bold">3</div>
          <div>
            <div class="text-xs font-bold text-slate-900">3. Dispatched</div>
            <div class="text-[10px] text-slate-500">Courier transit</div>
          </div>
        </div>

        <div class="p-3 rounded-xl ${order.shipmentStatus === 'DELIVERED' ? 'bg-slate-50' : 'opacity-40'} flex items-center gap-3">
          <div class="w-7 h-7 rounded-full ${order.shipmentStatus === 'DELIVERED' ? 'bg-emerald-600 text-white' : 'bg-slate-300'} flex items-center justify-center text-xs font-bold">4</div>
          <div>
            <div class="text-xs font-bold text-slate-900">4. Cash Collected</div>
            <div class="text-[10px] text-slate-500">Doorstep payment</div>
          </div>
        </div>
      </div>

      <!-- Details -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
        <div class="bg-slate-50 p-4 rounded-xl space-y-2">
          <span class="font-bold text-slate-700 uppercase tracking-wider text-[10px]">Delivery Address & Owner</span>
          <div class="font-bold text-slate-900">${order.address.text}</div>
          <div class="text-slate-600">${order.address.city} - ${order.address.pincode} (${order.address.landmark})</div>
          <div class="text-slate-700 pt-1 border-t border-slate-200">
            Registered Owner: <strong>${order.owner.name}</strong> (${order.owner.phone})
          </div>
        </div>

        <div class="bg-slate-50 p-4 rounded-xl space-y-2">
          <span class="font-bold text-slate-700 uppercase tracking-wider text-[10px]">Buyer Info & Log Notes</span>
          <div class="font-bold text-slate-900">Buyer: ${order.buyer.name} (${order.buyer.phone})</div>
          <div class="text-slate-600 italic">"${order.notes}"</div>
        </div>
      </div>
    </div>
  `;
  lucide.createIcons();
}

// Reset Demo Data
async function resetDemoData() {
  if (!confirm("Reset database to initial demo state?")) return;
  await fetch('/api/reset', { method: 'POST' });
  await loadOrders();
  await loadAnalytics();
  renderOrdersTable();
  renderOwnerVerificationPortal();
  showToast("Demo Data Restored", "All orders reset to initial sample states.");
}

// Helpers
function formatShipmentStatus(status) {
  const map = {
    'ON_HOLD': 'On Hold (Awaiting Owner)',
    'APPROVED_FOR_DISPATCH': 'Ready for Dispatch',
    'DISPATCHED': 'Dispatched',
    'OUT_FOR_DELIVERY': 'Out for Delivery',
    'DELIVERED': 'Delivered & Paid',
    'CANCELLED_UNAUTHORIZED': 'Cancelled (Unauthorized)'
  };
  return map[status] || status;
}

function getShipmentBadgeClass(status) {
  const map = {
    'ON_HOLD': 'bg-amber-100 text-amber-900 border border-amber-300',
    'APPROVED_FOR_DISPATCH': 'bg-blue-100 text-blue-900 border border-blue-300',
    'DISPATCHED': 'bg-indigo-100 text-indigo-900',
    'OUT_FOR_DELIVERY': 'bg-purple-100 text-purple-900',
    'DELIVERED': 'bg-emerald-100 text-emerald-900',
    'CANCELLED_UNAUTHORIZED': 'bg-rose-100 text-rose-900 border border-rose-300'
  };
  return map[status] || 'bg-slate-100 text-slate-800';
}

function showToast(title, message) {
  const toast = document.getElementById('toast');
  document.getElementById('toast-title').innerText = title;
  document.getElementById('toast-message').innerText = message;
  toast.classList.remove('opacity-0', 'translate-y-24');
  setTimeout(() => toast.classList.add('opacity-0', 'translate-y-24'), 4000);
}

window.addEventListener('DOMContentLoaded', initApp);
